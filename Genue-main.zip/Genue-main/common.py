
from ibm_watson_machine_learning.foundation_models import Model


from ibm_watson_machine_learning.foundation_models import Model

creds = {
		"url" : "https://us-south.ml.cloud.ibm.com",
		"apikey" : "--API-Key--"
    
}
project_id = "5a37191b-d394-4d86-9fa0-351621b49ff0" #Genue techzone account

## helper function
def generate_text(model, prompt_input):
	generated_text = model.generate_text(prompt=prompt_input)
	return generated_text

def generate_stream(model, prompt_input):
	generated_stream = model.generate_text_stream(prompt=prompt_input)
	return generated_stream

## helper function for model object
def get_model(model_id, decoding_method="greedy", min_tokens=1, max_tokens=500, repetition_penalty=1):
	parameters = {
        "decoding_method": decoding_method,
        "min_new_tokens": min_tokens,
        "max_new_tokens": max_tokens,
		"repetition_penalty": repetition_penalty
    }
	model =  Model(
        model_id = model_id,
        params = parameters,
        credentials = creds,
		project_id = project_id
    )
	return model

